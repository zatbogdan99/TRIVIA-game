#include <ncurses.h>
#include <string.h>
#include <stdio.h>
#include <stdlib.h>
#include <time.h>
#define CULOARE_FUNDAL 1
#define CULOARE_FERESTRE 2
#define CULOARE_SCRIS 3
#define CULOARE_TITLU 4
typedef struct intrebare{
	char intrebarea[256];
	char raspuns_A[256];
	char raspuns_B[256];
	char raspuns_C[256];
	char raspuns_D[256];
	char raspuns_corect[256];
};
typedef struct ajutoare{
	char da_sau_nu[3];
	int numaratoare;
	int scor;
	int boolean;
	int boolean2;
	int raspunsuri_corecte;
	int raspunsuri_gresite;
};
//Subprogram pentru crearea unei ferestre
WINDOW *creare_fereastra(int inaltime,int latime,int startx,int starty);	
struct ajutoare Start_game(WINDOW *NEW_GAME,WINDOW *RESUME_GAME,WINDOW *QUIT,int linii,int coloane,struct intrebare v[256],int a,struct ajutoare alfa,int numaratoare,int scor);//Inceperea efectiva a jocului
//Subprogram pentru crearea titlului folosind numarul de linii si de coloane
void creare_titlu();		
//Preluarea intrebarilor dintr-un fisier text in vectorul de structuri
int preluare_intrebari(struct intrebare *v,int i,char *s2);     
//Subprogram pentru afisarea unei intrebasi cu variantele					
void afisare_intrebare_si_variante(int numaratoare,int linii,int coloane,struct intrebare v[256],struct ajutoare alfa);        
//Subprogram pentru afisarea datei si orei curente
void data_si_ora(int linii,int coloane);
//Subprogram pentru afisarea meniului fara optiunea Resume Game accesibila
int meniu(int linii,int coloane);
//Subprogram pentru afisarea meniului cu optiunea Resume Game activata
int meniu2(int linii,int coloane);
//Subprogram folosit pentru afisarea optiunii 50/50,dar si a optiunii Skip the question,atat cand sunt active,cat si dupa ce au fost folosite
void optiunea50_50(struct ajutoare alfa,int linii,int coloane);


int main (int argc,char **argv)
{
	int a=0;
	
	  if (argc<=1)
	  	{
	  		//Daca nu s-au dat argumente in linia de comanda,afiseaza eroare
	  		printf("[Eroare]:Nu s-au dat argumente in linia de comanda.");  
	  		return 1;
	  	}
	struct intrebare v[256];
	struct ajutoare alfa;
	alfa.boolean=1;
	alfa.boolean2=1;
	alfa.raspunsuri_corecte=0;
	alfa.raspunsuri_gresite=0;
	int contorul_nostru;
	for (int contorul_meu=1;contorul_meu<argc;contorul_meu++)  //Preluarea intrebarilor din toate fisierele text
			{
				contorul_nostru=preluare_intrebari(v,a,argv[contorul_meu]);
				a+=contorul_nostru;
			}

	int linii,coloane,y,startx,starty,linii2,coloane2,k,l,aux,activare_resume=0;	
	char *p,s[]="nu"	;      p=s;
	WINDOW *NEW_GAME,*RESUME_GAME,*QUIT;
	
	initscr();
	start_color();
	init_pair(CULOARE_FUNDAL,COLOR_CYAN,COLOR_CYAN);
	init_pair(CULOARE_FERESTRE,COLOR_YELLOW,COLOR_BLUE);
	init_pair(CULOARE_SCRIS,COLOR_YELLOW,COLOR_BLACK);
	init_pair(CULOARE_TITLU,COLOR_YELLOW,COLOR_BLACK);
	
	getmaxyx(stdscr,linii,coloane);


	creare_titlu(linii,coloane);
	refresh();
	noecho();
	cbreak();
	keypad(stdscr,true);

	meniu_principal:

	if (activare_resume==0)
			aux=meniu(linii,coloane);
	else
			aux=meniu2(linii,coloane);
		if (aux==0)    //Daca ne aflam cu selectia pe Start Game 
			{
				alfa.raspunsuri_corecte=0;
				alfa.raspunsuri_gresite=0;
				optiunea50_50(alfa,linii,coloane);	//Afiseaza optiunile ajutatoare in functie de alfa.boolean1 si alfa.boolean2
				refresh();
				alfa.boolean=1;
				alfa.boolean2=1;
				attron(COLOR_PAIR(CULOARE_FUNDAL));
				for(y=12;y<linii;y++)
				mvhline(y,0,' ',coloane);
				attroff(COLOR_PAIR(CULOARE_FUNDAL));
				data_si_ora(linii,coloane);
				alfa=Start_game(NEW_GAME,RESUME_GAME,QUIT,linii,coloane,v,a,alfa,1,0);	//Inceperea efectiva a jocului
				a=0;
				for (int contorul_meu=1;contorul_meu<argc;contorul_meu++)
					{
					contorul_nostru=preluare_intrebari(v,a,argv[contorul_meu]);
					a+=contorul_nostru;
					}
				optiunea50_50(alfa,linii,coloane);
				//Secventa urmatoare e folosita pentru functionarea optiunii resume,daca q este apasat
				if (strcmp(alfa.da_sau_nu,s)==0)		
					{
						alfa.boolean=1;
						goto meniu_principal;
					}
				
				else
					if (alfa.numaratoare==-1)
						{
						activare_resume=0;
						alfa.numaratoare=1;
						alfa.boolean=1;
							goto meniu_principal;	
						}
					else
						{
							activare_resume=1;
							goto meniu_principal;
						}
			}
		 if (aux==1)	//Daca ne aflam cu selectia pe Resume game
		 {	attron(COLOR_PAIR(CULOARE_FUNDAL));
		 		for (int k=12;k<linii;k++)
		 			for (int j=0;j<coloane;j++)
		 				mvprintw(k,j," ");
		 	attroff(COLOR_PAIR(CULOARE_FUNDAL));
		 		afisare_intrebare_si_variante(alfa.numaratoare,linii,coloane,v,alfa);
		 		alfa=Start_game(NEW_GAME,RESUME_GAME,QUIT,linii,coloane,v,a,alfa,alfa.numaratoare,alfa.scor);
		 		a=0;
		 		for (int contorul_meu=1;contorul_meu<argc;contorul_meu++)
				{
					contorul_nostru=preluare_intrebari(v,a,argv[contorul_meu]);
					a+=contorul_nostru;
				}
		 		aux=0;
		 		if (strcmp(alfa.da_sau_nu,s)==0)
					goto meniu_principal;
				else
					if (alfa.numaratoare==-1)
						{
						activare_resume=0;
							alfa.numaratoare=1;
							goto meniu_principal;	
						}
					else
						{
							activare_resume=1;
							goto meniu_principal;
						}
		 }
		if (aux==2)
			endwin();

	endwin();	
}

WINDOW *creare_fereastra(int inaltime,int latime,int startx,int starty)
{
	WINDOW *window;
	window=newwin(inaltime,latime,startx,starty);
	box(window,0,0);
	wrefresh(window);
	return window;
}

void creare_titlu(int linii,int coloane)
{
	int startx,starty;
	startx=linii/10;
	starty=coloane/2-30;
	attron(COLOR_PAIR(CULOARE_TITLU));
	for (int i=startx;i<=startx+6;i++)		mvprintw(i,starty," ");    
	for (int i=starty-5;i<=starty+5;i++)    mvprintw(startx,i," ");   //  T
	starty=starty+12;													//Ne repozitionam pentru R
	for (int i=startx;i<=startx+6;i++)      mvprintw(i,starty," ");		//  R
	for (int i=starty;i<=starty+8;i++)      mvprintw(startx,i," ");		//  R
	for (int i=startx;i<=startx+3;i++)		mvprintw(i,starty+8," ");	//  R
	for (int i=starty;i<=starty+8;i++)      mvprintw(startx+3,i," ");	//	R
	for (int i=startx+3,j=starty;i<=startx+6;i++,j+=2)        mvprintw(i,j,"  ");  //  R
	starty+=16;																		 //  Ne repozitionam pentru I	
	for (int i=startx;i<=startx+6;i++)		mvprintw(i,starty," ");					 //  I
											mvprintw(startx-2,starty," ");			 //  I
	starty+=4;																		 //  Ne repozitionam pentru V
	for (int i=startx ,j=starty;i<=startx+6;i++,j++)        mvprintw(i,j," ");	 //  V
	for (int i=startx+6,j=starty+6;i>=startx;i--,j++)        mvprintw(i,j," ");	 //  V
	starty+=16;																		 //  Ne repozitionam pentru al doilea I
	for (int i=startx;i<=startx+6;i++)		mvprintw(i,starty," ");					 //  I
											mvprintw(startx-2,starty," ");			 //  I
	starty+=4;																		 //  Ne repozitionam pentru A
	for (int i=startx+6,j=starty;i>=startx;i--,j++)        mvprintw(i,j," ");		 //  A
	for (int i=startx ,j=starty+6;i<=startx+6;i++,j++)    mvprintw(i,j," ");		 //  A
	for (int i=starty+4;i<=starty+8;i++)   				mvprintw(startx+3,i," ");	 //  A
	attroff(COLOR_PAIR(CULOARE_TITLU));
}

struct ajutoare Start_game(WINDOW *NEW_GAME,WINDOW *RESUME_GAME,WINDOW *QUIT,int linii,int coloane,struct intrebare v[256],int a,struct ajutoare alfa,int numaratoare,int scor)
{
	srand(time(NULL));
	int startx,starty,linii2,coloane2,l,k,colorat=0,contor=0,z=1,y,dr,r;
	char raspuns_ales[256];
	delwin(NEW_GAME);
	delwin(RESUME_GAME);
	delwin(QUIT);
	refresh();
	if (linii>24)
		mvprintw(6*(linii/12)+1,5*(coloane/6),"Scor:%d",scor);
	else
		mvprintw(6*(linii/12)+2,5*(coloane/6),"Scor:%d",scor);
	
	afisare_intrebare_si_variante(numaratoare,linii,coloane,v,alfa);

	attron(COLOR_PAIR(CULOARE_FUNDAL));
	for (int i=0;i<coloane;i++)
		{
			mvprintw(5*(linii/12),i," ");
			mvprintw(5*(linii/12)+1,i," ");
		}

	attroff(COLOR_PAIR(CULOARE_FUNDAL));	
	int c;		//Variabila in care se stocheaza o tasta cand este apasata
	while (numaratoare<=a)
	{
	c=getch();
	optiunea50_50(alfa,linii,coloane);
	refresh();
	data_si_ora(linii,coloane);
	while (c!=10)
	{
			switch (c)
	{
		case 259:			//sageata sus
			{
				colorat--;
					if (colorat==-1)
						colorat=3;
				z=1;
				data_si_ora(linii,coloane);
				break;
			}

		case 258:          //sageata jos
			{
				colorat++;
					if (colorat==4)
						colorat=0;
				z=1;
				data_si_ora(linii,coloane);
				break;
			}
		case 10:				//enter
			{
				data_si_ora(linii,coloane);
				z=0;
				optiunea50_50(alfa,linii,coloane);
				refresh();
				break;
			}
		case 113:                //q
		{
			char s[]="da";
			strcpy(alfa.da_sau_nu,s);
			alfa.numaratoare=numaratoare;
			alfa.scor=scor;
			return alfa;
		}
		case 81:					//Q
		{
			char s[]="da";
			strcpy(alfa.da_sau_nu,s);
			alfa.numaratoare=numaratoare;
			alfa.scor=scor;
			return alfa;
		}
		case 49:					//tasta 1
		{
		if (alfa.boolean==1)
		{
			data_si_ora(linii,coloane);
			optiunea50_50(alfa,linii,coloane);
			y=rand() % 4;
			dr=0;
			while(dr==0)
			{	
			if (y==0)
				{
				if (strcmp(v[numaratoare-1].raspuns_A,v[numaratoare-1].raspuns_corect)!=0)
					{
						strcpy(v[numaratoare-1].raspuns_A,"-");
						dr=1;
					}
				else
					y=rand() % 4;
				}
			if (y==1)
				{
				if (strcmp(v[numaratoare-1].raspuns_B,v[numaratoare-1].raspuns_corect)!=0)
					{
						strcpy(v[numaratoare-1].raspuns_B,"-");
						dr=1;
					}
				else
					y=rand() % 4;
				}
			if (y==2)
				{
				if (strcmp(v[numaratoare-1].raspuns_C,v[numaratoare-1].raspuns_corect)!=0)
					{
						strcpy(v[numaratoare-1].raspuns_C,"-");
						dr=1;
					}
				else
					y=rand() % 4;
				}
			if (y==3)
				{
				if (strcmp(v[numaratoare-1].raspuns_D,v[numaratoare-1].raspuns_corect)!=0)
					{
						strcpy(v[numaratoare-1].raspuns_D,"-");
						dr=1;
					}
				else
					y=rand() % 4;
				}
			}
			// mvprintw(2,1,"%d",y);
			 r=y;
			 srand(time(NULL));
			 while (y==r)
			 	y=rand() % 4;
			 dr=0;
			 while(dr==0)
			 {	
			 if (y==0)
					if (strcmp(v[numaratoare-1].raspuns_A,v[numaratoare-1].raspuns_corect)!=0)
						{
							strcpy(v[numaratoare-1].raspuns_A,"-");
			 				dr=1;
					}
			 		else
			 			y=rand() % 4;
					
			if (y==1)
					if (strcmp(v[numaratoare-1].raspuns_B,v[numaratoare-1].raspuns_corect)!=0)
						{
							strcpy(v[numaratoare-1].raspuns_B,"-");
							dr=1;
						}
					else
						y=rand() % 4;
					
			if (y==2)
					if (strcmp(v[numaratoare-1].raspuns_C,v[numaratoare-1].raspuns_corect)!=0)
						{
							strcpy(v[numaratoare-1].raspuns_C,"-");
							dr=1;
						}
					else
						y=rand() % 4;

			if (y==3)
					if (strcmp(v[numaratoare-1].raspuns_D,v[numaratoare-1].raspuns_corect)!=0)
						{
							strcpy(v[numaratoare-1].raspuns_D,"-");
							dr=1;
						}
					else
						y=rand() % 4;


			 	}
			 	refresh();
			 alfa.boolean=0;
			 optiunea50_50(alfa,linii,coloane);
			 afisare_intrebare_si_variante(numaratoare,linii,coloane,v,alfa);
			 refresh();
			 z=1;
			 colorat=0;
			break;

		}
		else
			{
				z=1;
				colorat=0;
				break;
			}
		}
		case 50:		//tasta 2
		{
			if (alfa.boolean2==1)
				{
					alfa.boolean2=0;
					z=1;
					numaratoare++;
					afisare_intrebare_si_variante(numaratoare,linii,coloane,v,alfa);
					refresh();
					colorat=0;
					break;
				}
			else
			{
				z=1;
				break;
			}
		}
		default:break;
	}
	//  In continuare sunt afisate raspunsurile la intrebare in functia de pozitia pe care trebuie sa se afle selectia
		attron(COLOR_PAIR(CULOARE_FUNDAL));
		for (int i=11*(linii/12)+1;i<=linii-3;i++)
			for (int j=0;j<=coloane;j++)
				mvprintw(i,j," ");
		attroff(COLOR_PAIR(CULOARE_FUNDAL));
		optiunea50_50(alfa,linii,coloane);
		refresh();	
		if (colorat==0 && z==1)
		{
			starty=0;
			attron(COLOR_PAIR(CULOARE_FUNDAL));
			for (int i=0;i<coloane;i++)
				{
					mvprintw(8*(linii/12),starty," ");   starty++;
				}
			optiunea50_50(alfa,linii,coloane);
			attroff(COLOR_PAIR(CULOARE_FUNDAL));
			attron(COLOR_PAIR(CULOARE_TITLU));
			mvprintw(8*(linii/12),coloane/2-strlen(v[numaratoare-1].intrebarea)/2,"A.%s",v[numaratoare-1].raspuns_A);
			attroff(COLOR_PAIR(CULOARE_TITLU));
			starty=coloane/2;
			attron(COLOR_PAIR(CULOARE_FUNDAL));
			for (int i=0;i<coloane-strlen(v[numaratoare-1].intrebarea);i++)
				{
					mvprintw(8*(linii/12),starty+strlen(v[numaratoare-1].raspuns_A)," ");
					starty++;
				}
			attroff(COLOR_PAIR(CULOARE_FUNDAL));


			starty=0;
	attron(COLOR_PAIR(CULOARE_FUNDAL));
	for (int i=0;i<coloane;i++)
		{
			mvprintw(9*(linii/12),starty," ");   starty++;
		}
	attroff(COLOR_PAIR(CULOARE_FUNDAL));
	mvprintw(9*(linii/12),coloane/2-strlen(v[numaratoare-1].intrebarea)/2,"B.%s",v[numaratoare-1].raspuns_B);
	starty=coloane/2;
	attron(COLOR_PAIR(CULOARE_FUNDAL));
	for (int i=0;i<coloane-strlen(v[numaratoare-1].intrebarea);i++)
		{
			mvprintw(9*(linii/12),starty+strlen(v[numaratoare-1].raspuns_B)," ");
			starty++;
		}
	attroff(COLOR_PAIR(CULOARE_FUNDAL));


	starty=0;
	attron(COLOR_PAIR(CULOARE_FUNDAL));
	for (int i=0;i<coloane;i++)
		{
			mvprintw(10*(linii/12),starty," ");   starty++;
		}
	attroff(COLOR_PAIR(CULOARE_FUNDAL));
	mvprintw(10*(linii/12),coloane/2-strlen(v[numaratoare-1].intrebarea)/2,"C.%s",v[numaratoare-1].raspuns_C);
	starty=coloane/2;
	attron(COLOR_PAIR(CULOARE_FUNDAL));
	for (int i=0;i<coloane-strlen(v[numaratoare-1].intrebarea);i++)
		{
			mvprintw(10*(linii/12),starty+strlen(v[numaratoare-1].raspuns_C)," ");
			starty++;
		}
	attroff(COLOR_PAIR(CULOARE_FUNDAL));


	starty=0;
	attron(COLOR_PAIR(CULOARE_FUNDAL));
	for (int i=0;i<coloane;i++)
		{
			mvprintw(11*(linii/12),starty," ");   starty++;
		}
	attroff(COLOR_PAIR(CULOARE_FUNDAL));
	mvprintw(11*(linii/12),coloane/2-strlen(v[numaratoare-1].intrebarea)/2,"D.%s",v[numaratoare-1].raspuns_D);
	starty=coloane/2;
	attron(COLOR_PAIR(CULOARE_FUNDAL));
	for (int i=0;i<coloane-strlen(v[numaratoare-1].intrebarea);i++)
		{
			mvprintw(11*(linii/12),starty+strlen(v[numaratoare-1].raspuns_D)," ");
			starty++;
		}
	attroff(COLOR_PAIR(CULOARE_FUNDAL));
		strcpy(raspuns_ales,v[numaratoare-1].raspuns_A);
		optiunea50_50(alfa,linii,coloane);
		refresh();
		}



		if (colorat==1 && z==1)
		{
			optiunea50_50(alfa,linii,coloane);
			startx=5*linii/12;  l=startx;
	starty=0;
	attron(COLOR_PAIR(CULOARE_FUNDAL));
	for (int i=0;i<coloane;i++)
		{
			if (linii>24)
				{
					mvprintw(6*(linii/12),starty," ");   starty++;
				}
			else
				{
					mvprintw(6*(linii/12)+1,starty," ");   starty++;
				}
		}
	attroff(COLOR_PAIR(CULOARE_FUNDAL));
	if (linii>24)
		mvprintw(6*(linii/12),coloane/2-strlen(v[numaratoare-1].intrebarea)/2,"%d.%s",numaratoare,v[numaratoare-1].intrebarea);
	else
		mvprintw(6*(linii/12)+1,coloane/2-strlen(v[numaratoare-1].intrebarea)/2,"%d.%s",numaratoare,v[numaratoare-1].intrebarea);
	starty=coloane/2;
	attron(COLOR_PAIR(CULOARE_FUNDAL));
	for (int i=0;i<coloane-strlen(v[numaratoare-1].intrebarea);i++)
		{
			mvprintw(6*(linii/12),starty+strlen(v[numaratoare-1].intrebarea)," ");
			starty++;
		}
	attroff(COLOR_PAIR(CULOARE_FUNDAL));

	starty=0;
	attron(COLOR_PAIR(CULOARE_FUNDAL));
	for (int i=0;i<coloane;i++)
		{
			mvprintw(8*(linii/12),starty," ");   starty++;
		}
	attroff(COLOR_PAIR(CULOARE_FUNDAL));
	mvprintw(8*(linii/12),coloane/2-strlen(v[numaratoare-1].intrebarea)/2,"A.%s",v[numaratoare-1].raspuns_A);
	starty=coloane/2;
	attron(COLOR_PAIR(CULOARE_FUNDAL));
	for (int i=0;i<coloane-strlen(v[numaratoare-1].intrebarea);i++)
		{
			mvprintw(8*(linii/12),starty+strlen(v[numaratoare-1].raspuns_A)," ");
			starty++;
		}
	attroff(COLOR_PAIR(CULOARE_FUNDAL));
	


	starty=0;
	attron(COLOR_PAIR(CULOARE_FUNDAL));
	for (int i=0;i<coloane;i++)
		{
			mvprintw(9*(linii/12),starty," ");   starty++;
		}
	attroff(COLOR_PAIR(CULOARE_FUNDAL));
	attron(COLOR_PAIR(CULOARE_TITLU));
	mvprintw(9*(linii/12),coloane/2-strlen(v[numaratoare-1].intrebarea)/2,"B.%s",v[numaratoare-1].raspuns_B);
	attroff(COLOR_PAIR(CULOARE_TITLU));
	starty=coloane/2;
	attron(COLOR_PAIR(CULOARE_FUNDAL));
	for (int i=0;i<coloane-strlen(v[numaratoare-1].intrebarea);i++)
		{
			mvprintw(9*(linii/12),starty+strlen(v[numaratoare-1].raspuns_B)," ");
			starty++;
		}
	attroff(COLOR_PAIR(CULOARE_FUNDAL));


	starty=0;
	attron(COLOR_PAIR(CULOARE_FUNDAL));
	for (int i=0;i<coloane;i++)
		{
			mvprintw(10*(linii/12),starty," ");   starty++;
		}
	attroff(COLOR_PAIR(CULOARE_FUNDAL));
	mvprintw(10*(linii/12),coloane/2-strlen(v[numaratoare-1].intrebarea)/2,"C.%s",v[numaratoare-1].raspuns_C);
	starty=coloane/2;
	attron(COLOR_PAIR(CULOARE_FUNDAL));
	for (int i=0;i<coloane-strlen(v[numaratoare-1].intrebarea);i++)
		{
			mvprintw(10*(linii/12),starty+strlen(v[numaratoare-1].raspuns_C)," ");
			starty++;
		}
	attroff(COLOR_PAIR(CULOARE_FUNDAL));


	starty=0;
	attron(COLOR_PAIR(CULOARE_FUNDAL));
	for (int i=0;i<coloane;i++)
		{
			mvprintw(11*(linii/12),starty," ");   starty++;
		}
	attroff(COLOR_PAIR(CULOARE_FUNDAL));
	mvprintw(11*(linii/12),coloane/2-strlen(v[numaratoare-1].intrebarea)/2,"D.%s",v[numaratoare-1].raspuns_D);
	starty=coloane/2;
	attron(COLOR_PAIR(CULOARE_FUNDAL));
	for (int i=0;i<coloane-strlen(v[numaratoare-1].intrebarea);i++)
		{
			mvprintw(11*(linii/12),starty+strlen(v[numaratoare-1].raspuns_D)," ");
			starty++;
		}
		attroff(COLOR_PAIR(CULOARE_FUNDAL));
		strcpy(raspuns_ales,v[numaratoare-1].raspuns_B);
		optiunea50_50(alfa,linii,coloane);
		refresh();
		}

	if (colorat==2  && z==1)
	{
		optiunea50_50(alfa,linii,coloane);
		startx=5*linii/12;  l=startx;
	starty=0;
	attron(COLOR_PAIR(CULOARE_FUNDAL));
	for (int i=0;i<coloane;i++)
		{
			if (linii>24)
				{
					mvprintw(6*(linii/12),starty," ");   starty++;
				}
			else
				{
					mvprintw(6*(linii/12)+1,starty," ");   starty++;
				}
		}
	attroff(COLOR_PAIR(CULOARE_FUNDAL));
	if (linii>24)
		mvprintw(6*(linii/12),coloane/2-strlen(v[numaratoare-1].intrebarea)/2,"%d.%s",numaratoare,v[numaratoare-1].intrebarea);
	else
		mvprintw(6*(linii/12)+1,coloane/2-strlen(v[numaratoare-1].intrebarea)/2,"%d.%s",numaratoare,v[numaratoare-1].intrebarea);
	starty=coloane/2;
	attron(COLOR_PAIR(CULOARE_FUNDAL));
	for (int i=0;i<coloane-strlen(v[numaratoare-1].intrebarea);i++)
		{
			mvprintw(6*(linii/12),starty+strlen(v[numaratoare-1].intrebarea)," ");
			starty++;
		}
	attroff(COLOR_PAIR(CULOARE_FUNDAL));

	starty=0;
	attron(COLOR_PAIR(CULOARE_FUNDAL));
	for (int i=0;i<coloane;i++)
		{
			mvprintw(8*(linii/12),starty," ");   starty++;
		}
	attroff(COLOR_PAIR(CULOARE_FUNDAL));
	mvprintw(8*(linii/12),coloane/2-strlen(v[numaratoare-1].intrebarea)/2,"A.%s",v[numaratoare-1].raspuns_A);
	starty=coloane/2;
	attron(COLOR_PAIR(CULOARE_FUNDAL));
	for (int i=0;i<coloane-strlen(v[numaratoare-1].intrebarea);i++)
		{
			mvprintw(8*(linii/12),starty+strlen(v[numaratoare-1].raspuns_A)," ");
			starty++;
		}
	attroff(COLOR_PAIR(CULOARE_FUNDAL));
	


	starty=0;
	attron(COLOR_PAIR(CULOARE_FUNDAL));
	for (int i=0;i<coloane;i++)
		{
			mvprintw(9*(linii/12),starty," ");   starty++;
		}
	attroff(COLOR_PAIR(CULOARE_FUNDAL));
	mvprintw(9*(linii/12),coloane/2-strlen(v[numaratoare-1].intrebarea)/2,"B.%s",v[numaratoare-1].raspuns_B);
	starty=coloane/2;
	attron(COLOR_PAIR(CULOARE_FUNDAL));
	for (int i=0;i<coloane-strlen(v[numaratoare-1].intrebarea);i++)
		{
			mvprintw(9*(linii/12),starty+strlen(v[numaratoare-1].raspuns_B)," ");
			starty++;
		}
	attroff(COLOR_PAIR(CULOARE_FUNDAL));


	starty=0;
	attron(COLOR_PAIR(CULOARE_FUNDAL));
	for (int i=0;i<coloane;i++)
		{
			mvprintw(10*(linii/12),starty," ");   starty++;
		}
	attroff(COLOR_PAIR(CULOARE_FUNDAL));
	attron(COLOR_PAIR(CULOARE_TITLU));
	mvprintw(10*(linii/12),coloane/2-strlen(v[numaratoare-1].intrebarea)/2,"C.%s",v[numaratoare-1].raspuns_C);
	attroff(COLOR_PAIR(CULOARE_TITLU));
	starty=coloane/2;
	attron(COLOR_PAIR(CULOARE_FUNDAL));
	for (int i=0;i<coloane-strlen(v[numaratoare-1].intrebarea);i++)
		{
			mvprintw(10*(linii/12),starty+strlen(v[numaratoare-1].raspuns_C)," ");
			starty++;
		}
	attroff(COLOR_PAIR(CULOARE_FUNDAL));


	starty=0;
	attron(COLOR_PAIR(CULOARE_FUNDAL));
	for (int i=0;i<coloane;i++)
		{
			mvprintw(11*(linii/12),starty," ");   starty++;
		}
	attroff(COLOR_PAIR(CULOARE_FUNDAL));
	mvprintw(11*(linii/12),coloane/2-strlen(v[numaratoare-1].intrebarea)/2,"D.%s",v[numaratoare-1].raspuns_D);
	starty=coloane/2;
	attron(COLOR_PAIR(CULOARE_FUNDAL));
	for (int i=0;i<coloane-strlen(v[numaratoare-1].intrebarea);i++)
		{
			mvprintw(11*(linii/12),starty+strlen(v[numaratoare-1].raspuns_D)," ");
			starty++;
		}
	attroff(COLOR_PAIR(CULOARE_FUNDAL));
	strcpy(raspuns_ales,v[numaratoare-1].raspuns_C);
	optiunea50_50(alfa,linii,coloane);
	refresh();
	}


	if (colorat==3 && z==1)
	{
		startx=5*linii/12;  l=startx;
	starty=0;
	attron(COLOR_PAIR(CULOARE_FUNDAL));
	for (int i=0;i<coloane;i++)
		{
			if (linii>24)
				{
					mvprintw(6*(linii/12),starty," ");   starty++;
				}
			else
				{
					mvprintw(6*(linii/12)+1,starty," ");   starty++;
				}
		}
	optiunea50_50(alfa,linii,coloane);
	attroff(COLOR_PAIR(CULOARE_FUNDAL));
	if (linii>24)
		mvprintw(6*(linii/12),coloane/2-strlen(v[numaratoare-1].intrebarea)/2,"%d.%s",numaratoare,v[numaratoare-1].intrebarea);
	else
		mvprintw(6*(linii/12)+1,coloane/2-strlen(v[numaratoare-1].intrebarea)/2,"%d.%s",numaratoare,v[numaratoare-1].intrebarea);
	starty=coloane/2;
	attron(COLOR_PAIR(CULOARE_FUNDAL));
	for (int i=0;i<coloane-strlen(v[numaratoare-1].intrebarea);i++)
		{
			mvprintw(6*(linii/12),starty+strlen(v[numaratoare-1].intrebarea)," ");
			starty++;
		}
	attroff(COLOR_PAIR(CULOARE_FUNDAL));

	starty=0;
	attron(COLOR_PAIR(CULOARE_FUNDAL));
	for (int i=0;i<coloane;i++)
		{
			mvprintw(8*(linii/12),starty," ");   starty++;
		}
	attroff(COLOR_PAIR(CULOARE_FUNDAL));
	mvprintw(8*(linii/12),coloane/2-strlen(v[numaratoare-1].intrebarea)/2,"A.%s",v[numaratoare-1].raspuns_A);
	starty=coloane/2;
	attron(COLOR_PAIR(CULOARE_FUNDAL));
	for (int i=0;i<coloane-strlen(v[numaratoare-1].intrebarea);i++)
		{
			mvprintw(8*(linii/12),starty+strlen(v[numaratoare-1].raspuns_A)," ");
			starty++;
		}
	attroff(COLOR_PAIR(CULOARE_FUNDAL));
	


	starty=0;
	attron(COLOR_PAIR(CULOARE_FUNDAL));
	for (int i=0;i<coloane;i++)
		{
			mvprintw(9*(linii/12),starty," ");   starty++;
		}
	attroff(COLOR_PAIR(CULOARE_FUNDAL));
	mvprintw(9*(linii/12),coloane/2-strlen(v[numaratoare-1].intrebarea)/2,"B.%s",v[numaratoare-1].raspuns_B);
	starty=coloane/2;
	attron(COLOR_PAIR(CULOARE_FUNDAL));
	for (int i=0;i<coloane-strlen(v[numaratoare-1].intrebarea);i++)
		{
			mvprintw(9*(linii/12),starty+strlen(v[numaratoare-1].raspuns_B)," ");
			starty++;
		}
	attroff(COLOR_PAIR(CULOARE_FUNDAL));


	starty=0;
	attron(COLOR_PAIR(CULOARE_FUNDAL));
	for (int i=0;i<coloane;i++)
		{
			mvprintw(10*(linii/12),starty," ");   starty++;
		}
	attroff(COLOR_PAIR(CULOARE_FUNDAL));
	mvprintw(10*(linii/12),coloane/2-strlen(v[numaratoare-1].intrebarea)/2,"C.%s",v[numaratoare-1].raspuns_C);
	starty=coloane/2;
	attron(COLOR_PAIR(CULOARE_FUNDAL));
	for (int i=0;i<coloane-strlen(v[numaratoare-1].intrebarea);i++)
		{
			mvprintw(10*(linii/12),starty+strlen(v[numaratoare-1].raspuns_C)," ");
			starty++;
		}
	attroff(COLOR_PAIR(CULOARE_FUNDAL));


	starty=0;
	attron(COLOR_PAIR(CULOARE_FUNDAL));
	for (int i=0;i<coloane;i++)
		{
			mvprintw(11*(linii/12),starty," ");   starty++;
		}
	attroff(COLOR_PAIR(CULOARE_FUNDAL));
	attron(COLOR_PAIR(CULOARE_TITLU));
	mvprintw(11*(linii/12),coloane/2-strlen(v[numaratoare-1].intrebarea)/2,"D.%s",v[numaratoare-1].raspuns_D);
	attron(COLOR_PAIR(CULOARE_TITLU));
	starty=coloane/2;
	attron(COLOR_PAIR(CULOARE_FUNDAL));
	for (int i=0;i<coloane-strlen(v[numaratoare-1].intrebarea);i++)
		{
			mvprintw(11*(linii/12),starty+strlen(v[numaratoare-1].raspuns_D)," ");
			starty++;
		}
	attroff(COLOR_PAIR(CULOARE_FUNDAL));
	strcpy(raspuns_ales,v[numaratoare-1].raspuns_D);
	optiunea50_50(alfa,linii,coloane);
	refresh();
	}
	if (z==1)
		{
			c=getch();
			data_si_ora(linii,coloane);
			optiunea50_50(alfa,linii,coloane);
				refresh();
		}

	}
	//Contorizare scor
	if (strcmp(raspuns_ales,v[numaratoare-1].raspuns_corect)==0)
		{
			scor+=10;
			alfa.raspunsuri_corecte++;
		}
	
	else
		{	
			scor-=5;
			alfa.raspunsuri_gresite++;
		}	

		numaratoare++;
	afisare_intrebare_si_variante(numaratoare,linii,coloane,v,alfa);
	if (linii>24)
		mvprintw(6*(linii/12)+1,5*(coloane/6),"Scor:%d",scor);
	else
		mvprintw(6*(linii/12)+2,5*(coloane/6),"Scor:%d",scor);
	colorat=0;
	optiunea50_50(alfa,linii,coloane);
	refresh();
	}
	attron(COLOR_PAIR(CULOARE_FUNDAL));
	for (int i=5*(linii/12);i<linii;i++)
		for (int j=1;j<coloane;j++)
			mvprintw(i,j," ");
	attroff(COLOR_PAIR(CULOARE_FUNDAL));
	mvprintw(8*(linii/12),coloane/2-5,"Felicitari!");
	mvprintw(8*(linii/12)+2,coloane/2-10,"Ati obtinut scorul:%d din %d",scor,a*10);
	mvprintw(8*(linii/12)+3,coloane/2-22,"Ati raspuns corect la %d intrebari si gresit la %d",alfa.raspunsuri_corecte,alfa.raspunsuri_gresite);
	mvprintw(10*(linii/12)+2,coloane/2-6,"Press any key...");
	data_si_ora(linii,coloane);
	alfa.numaratoare=-1;
	alfa.boolean=1;
	alfa.boolean2=1;
	refresh();
	getch();
	optiunea50_50(alfa,linii,coloane);
	refresh();
	data_si_ora(linii,coloane);
	return alfa;
	//endwin();

}

int preluare_intrebari(struct intrebare v[256],int i,char *s2)
{
	int z=0;
	char s[256];
	FILE *f;
	if ((f=fopen(s2,"r"))==NULL)
		{
			printf("Nu se poate deschide un fisier cu intrebari\n");
			exit(1);
		}
	while(fgets(s,256,f)!=NULL)
	{
		strcpy(v[i].intrebarea,s);
		if (fgets(s,256,f)!=NULL)
			strcpy(v[i].raspuns_A,s);
		if (fgets(s,256,f)!=NULL)
			strcpy(v[i].raspuns_B,s);
		if (fgets(s,256,f)!=NULL)
			strcpy(v[i].raspuns_C,s);
		if (fgets(s,256,f)!=NULL)
			strcpy(v[i].raspuns_D,s);
		if (fgets(s,256,f)!=NULL)
			strcpy(v[i].raspuns_corect,s);
		i++;
		z++;
	}
	fclose(f);
	return z;
}

void afisare_intrebare_si_variante(int numaratoare,int linii,int coloane,struct intrebare v[256],struct ajutoare alfa)
{
	int startx,starty,l;
	startx=5*linii/12;  l=startx;
	starty=0;
	attron(COLOR_PAIR(CULOARE_FUNDAL));
	for (int i=6*(linii/12);i<=linii-3;i++)
		for (int j=0;j<coloane;j++)
			mvprintw(i,j," ");
	for (int i=0;i<coloane;i++)
		{
			if (linii>24)
				{
					mvprintw(6*(linii/12),starty," ");   starty++;
				}
			else
				{
					mvprintw(6*(linii/12)+1,starty," ");   starty++;
				}
		}
	optiunea50_50(alfa,linii,coloane);
	attroff(COLOR_PAIR(CULOARE_FUNDAL));
	if (linii>24)
		mvprintw(6*(linii/12),coloane/2-strlen(v[numaratoare-1].intrebarea)/2,"%d.%s",numaratoare,v[numaratoare-1].intrebarea);
	else
		mvprintw(6*(linii/12)+1,coloane/2-strlen(v[numaratoare-1].intrebarea)/2,"%d.%s",numaratoare,v[numaratoare-1].intrebarea);
	starty=coloane/2;
	attron(COLOR_PAIR(CULOARE_FUNDAL));
	for (int i=0;i<coloane-strlen(v[numaratoare-1].intrebarea);i++)
		{
			mvprintw(6*(linii/12),starty+strlen(v[numaratoare-1].intrebarea)," ");
			starty++;
		}
	attroff(COLOR_PAIR(CULOARE_FUNDAL));

	starty=0;
	attron(COLOR_PAIR(CULOARE_FUNDAL));
	for (int i=0;i<coloane;i++)
		{
			mvprintw(8*(linii/12),starty," ");   starty++;
		}
	attroff(COLOR_PAIR(CULOARE_FUNDAL));
	attron(COLOR_PAIR(CULOARE_TITLU));
	mvprintw(8*(linii/12),coloane/2-strlen(v[numaratoare-1].intrebarea)/2,"A.%s",v[numaratoare-1].raspuns_A);
	attroff(COLOR_PAIR(CULOARE_TITLU));
	starty=coloane/2;
	attron(COLOR_PAIR(CULOARE_FUNDAL));
	for (int i=0;i<coloane-strlen(v[numaratoare-1].intrebarea);i++)
		{
			mvprintw(8*(linii/12),starty+strlen(v[numaratoare-1].raspuns_A)," ");
			starty++;
		}
	attroff(COLOR_PAIR(CULOARE_FUNDAL));
	


	starty=0;
	attron(COLOR_PAIR(CULOARE_FUNDAL));
	for (int i=0;i<coloane;i++)
		{
			mvprintw(9*(linii/12),starty," ");   starty++;
		}
	attroff(COLOR_PAIR(CULOARE_FUNDAL));
	mvprintw(9*(linii/12),coloane/2-strlen(v[numaratoare-1].intrebarea)/2,"B.%s",v[numaratoare-1].raspuns_B);
	starty=coloane/2;
	attron(COLOR_PAIR(CULOARE_FUNDAL));
	for (int i=0;i<coloane-strlen(v[numaratoare-1].intrebarea);i++)
		{
			mvprintw(9*(linii/12),starty+strlen(v[numaratoare-1].raspuns_B)," ");
			starty++;
		}
	attroff(COLOR_PAIR(CULOARE_FUNDAL));


	starty=0;
	attron(COLOR_PAIR(CULOARE_FUNDAL));
	for (int i=0;i<coloane;i++)
		{
			mvprintw(10*(linii/12),starty," ");   starty++;
		}
	attroff(COLOR_PAIR(CULOARE_FUNDAL));
	mvprintw(10*(linii/12),coloane/2-strlen(v[numaratoare-1].intrebarea)/2,"C.%s",v[numaratoare-1].raspuns_C);
	starty=coloane/2;
	attron(COLOR_PAIR(CULOARE_FUNDAL));
	for (int i=0;i<coloane-strlen(v[numaratoare-1].intrebarea);i++)
		{
			mvprintw(10*(linii/12),starty+strlen(v[numaratoare-1].raspuns_C)," ");
			starty++;
		}
	attroff(COLOR_PAIR(CULOARE_FUNDAL));


	starty=0;
	attron(COLOR_PAIR(CULOARE_FUNDAL));
	for (int i=0;i<coloane;i++)
		{
			mvprintw(11*(linii/12),starty," ");   starty++;
		}
	attroff(COLOR_PAIR(CULOARE_FUNDAL));
	mvprintw(11*(linii/12),coloane/2-strlen(v[numaratoare-1].intrebarea)/2,"D.%s",v[numaratoare-1].raspuns_D);
	starty=coloane/2;
	attron(COLOR_PAIR(CULOARE_FUNDAL));
	for (int i=0;i<coloane-strlen(v[numaratoare-1].intrebarea);i++)
		{
			mvprintw(11*(linii/12),starty+strlen(v[numaratoare-1].raspuns_D)," ");
			starty++;
		}
	attroff(COLOR_PAIR(CULOARE_FUNDAL));
}

void data_si_ora (int linii,int coloane)
{
	time_t t;
	struct tm *timp;
	t=time(NULL);
	timp=localtime(&t);
	mvprintw(linii-2,2,"%s",asctime(timp));
	attron(COLOR_PAIR(CULOARE_FUNDAL));
	for (int i=0;i<coloane-strlen(asctime(timp));i++)
		mvprintw(linii-2,2+strlen(asctime(timp))+i," ");
	attroff(COLOR_PAIR(CULOARE_FUNDAL));
}

int meniu(int linii,int coloane)
{
	int y,startx,starty,linii2,coloane2,k,l,aux;
	WINDOW *NEW_GAME,*RESUME_GAME,*QUIT;
	refresh();
	attron(COLOR_PAIR(CULOARE_FUNDAL));
	for(y=0;y<=linii;y++)
		mvhline(y,0,' ',coloane);
	attroff(COLOR_PAIR(CULOARE_FUNDAL));
	
	startx=linii/4+4;  l=startx;
	starty=coloane/2-10;
	NEW_GAME=creare_fereastra(4,20,startx,starty);
	getmaxyx(NEW_GAME,linii2,coloane2);

	attron(COLOR_PAIR(CULOARE_FERESTRE));
	for (int i=linii2;i>0;i--)
		{
		k=starty;
		for (int j=coloane2;j>0;j--)
			{
				mvprintw(startx,k," ");
				k++;
			}
		startx++;
		}
	attroff(COLOR_PAIR(CULOARE_FERESTRE));
	data_si_ora(linii,coloane);

	mvprintw(l+linii2/2,starty+coloane2/2-4,"New Game"); 
	wrefresh(NEW_GAME);

	startx=2*(linii/4)+2; l=startx;
	starty=coloane/2-10;
	RESUME_GAME=creare_fereastra(4,20,startx,starty);
	getmaxyx(RESUME_GAME,linii2,coloane2);
	attron(COLOR_PAIR(CULOARE_FERESTRE));
	for (int i=linii2;i>0;i--)
		{
		k=starty;
		for (int j=coloane2;j>0;j--)
			{
				mvprintw(startx,k," ");
				k++;
			}
		startx++;
		}
	attroff(COLOR_PAIR(CULOARE_FERESTRE));

	attron(COLOR_PAIR(COLOR_RED));
	mvprintw(l+linii2/2,starty+coloane2/2-5,"Resume game"); 
	wrefresh(RESUME_GAME);
	attroff(COLOR_PAIR(COLOR_RED));


	startx=3*(linii/4);   l=startx;
	starty=coloane/2-10;
	QUIT=creare_fereastra(4,20,startx,starty);
	getmaxyx(QUIT,linii2,coloane2);
	attron(COLOR_PAIR(CULOARE_FERESTRE));
	for (int i=linii2;i>0;i--)
		{
		k=starty;
		for (int j=coloane2;j>0;j--)
			{
				mvprintw(startx,k," ");
				k++;
			}
		startx++;
		}
	attroff(COLOR_PAIR(CULOARE_FERESTRE));	

	mvprintw(l+linii2/2,starty+coloane2/2-2,"Quit"); 	
	wrefresh(QUIT);

	creare_titlu(linii,coloane);
	refresh();
	
	int colorat=0;
	noecho();
	cbreak();
	keypad(stdscr,true);
	keypad(NEW_GAME,true);
	keypad(RESUME_GAME,true);
	keypad(QUIT,true);
	int constanta=0;
	while(constanta==0)
	{
			if (colorat==0)
			{
				startx=2*(linii/4)+2; 
				starty=coloane/2-10;
				getmaxyx(RESUME_GAME,linii2,coloane2);
				mvprintw(startx+linii2/2,starty+coloane2/2-5,"(Resume Game)");

				startx=3*(linii/4);   
				starty=coloane/2-10;
				getmaxyx(QUIT,linii2,coloane2);
				mvprintw(startx+linii2/2,starty+coloane2/2-2,"Quit");

				startx=linii/4+4;  		
				starty=coloane/2-10;
				getmaxyx(NEW_GAME,linii2,coloane2);
				attron(COLOR_PAIR(CULOARE_TITLU));
				mvprintw(startx+linii2/2,starty+coloane2/2-4,"New Game");
				attroff(COLOR_PAIR(CULOARE_TITLU));
				data_si_ora(linii,coloane);
				refresh();
			}

			if (colorat==2)
			{

				startx=linii/4+4;  
				starty=coloane/2-10;
				getmaxyx(NEW_GAME,linii2,coloane2);
				mvprintw(startx+linii2/2,starty+coloane2/2-4,"New Game");
				
				startx=2*(linii/4)+2; 
				starty=coloane/2-10;
				getmaxyx(RESUME_GAME,linii2,coloane2);
				mvprintw(startx+linii2/2,starty+coloane2/2-5,"(Resume Game)");
				refresh();

				attron(COLOR_PAIR(CULOARE_TITLU));
				startx=3*(linii/4);   
				starty=coloane/2-10;
				getmaxyx(QUIT,linii2,coloane2);
				mvprintw(startx+linii2/2,starty+coloane2/2-2,"Quit");
				attroff(COLOR_PAIR(CULOARE_TITLU));
				refresh();

			}

		int varianta;
		varianta=getch();
		data_si_ora(linii,coloane);
		switch(varianta)
		{
			case 259:
					{
						colorat--;
						if (colorat==1)
							colorat=0;
						if (colorat==-1)
							colorat=2;
						break;
					}
			case 258:
					{
						colorat++;
						if (colorat==1)
							colorat=2;
						if (colorat==3)
							colorat=0;
						break;
					}
			case 10:
					{
						if (colorat==0)
							aux=0;
						if (colorat==1)
							aux=1;
						if (colorat==2)
							aux=2;
						constanta=1;
						break;
					}
			default:break;

		}
	}
	return aux;
}

int meniu2(int linii,int coloane)
{
	int y,startx,starty,linii2,coloane2,k,l,aux;
	WINDOW *NEW_GAME,*RESUME_GAME,*QUIT;
	refresh();
	attron(COLOR_PAIR(CULOARE_FUNDAL));
	for(y=0;y<=linii;y++)
		mvhline(y,0,' ',coloane);
	attroff(COLOR_PAIR(CULOARE_FUNDAL));
	
	startx=linii/4+4;  l=startx;
	starty=coloane/2-10;
	NEW_GAME=creare_fereastra(4,20,startx,starty);
	getmaxyx(NEW_GAME,linii2,coloane2);

	attron(COLOR_PAIR(CULOARE_FERESTRE));
	for (int i=linii2;i>0;i--)
		{
		k=starty;
		for (int j=coloane2;j>0;j--)
			{
				mvprintw(startx,k," ");
				k++;
			}
		startx++;
		}
	attroff(COLOR_PAIR(CULOARE_FERESTRE));
	data_si_ora(linii,coloane);

	mvprintw(l+linii2/2,starty+coloane2/2-4,"New Game"); 
	wrefresh(NEW_GAME);

	startx=2*(linii/4)+2; l=startx;
	starty=coloane/2-10;
	RESUME_GAME=creare_fereastra(4,20,startx,starty);
	getmaxyx(RESUME_GAME,linii2,coloane2);
	attron(COLOR_PAIR(CULOARE_FERESTRE));
	for (int i=linii2;i>0;i--)
		{
		k=starty;
		for (int j=coloane2;j>0;j--)
			{
				mvprintw(startx,k," ");
				k++;
			}
		startx++;
		}
	attroff(COLOR_PAIR(CULOARE_FERESTRE));

	mvprintw(l+linii2/2,starty+coloane2/2-5,"Resume game"); 
	wrefresh(RESUME_GAME);


	startx=3*(linii/4);   l=startx;
	starty=coloane/2-10;
	QUIT=creare_fereastra(4,20,startx,starty);
	getmaxyx(QUIT,linii2,coloane2);
	attron(COLOR_PAIR(CULOARE_FERESTRE));
	for (int i=linii2;i>0;i--)
		{
		k=starty;
		for (int j=coloane2;j>0;j--)
			{
				mvprintw(startx,k," ");
				k++;
			}
		startx++;
		}
	attroff(COLOR_PAIR(CULOARE_FERESTRE));	

	mvprintw(l+linii2/2,starty+coloane2/2-2,"Quit"); 	
	wrefresh(QUIT);

	creare_titlu(linii,coloane);
	refresh();
	
	int colorat=0;
	noecho();
	cbreak();
	keypad(stdscr,true);
	keypad(NEW_GAME,true);
	keypad(RESUME_GAME,true);
	keypad(QUIT,true);
	int constanta=0;
	while(constanta==0)
	{
			if (colorat==0)
			{
				startx=2*(linii/4)+2; 
				starty=coloane/2-10;
				getmaxyx(RESUME_GAME,linii2,coloane2);
				mvprintw(startx+linii2/2,starty+coloane2/2-5,"Resume Game");
				
				startx=3*(linii/4);   
				starty=coloane/2-10;
				getmaxyx(QUIT,linii2,coloane2);
				mvprintw(startx+linii2/2,starty+coloane2/2-2,"Quit");

				startx=linii/4+4;  		
				starty=coloane/2-10;
				getmaxyx(NEW_GAME,linii2,coloane2);
				attron(COLOR_PAIR(CULOARE_TITLU));
				mvprintw(startx+linii2/2,starty+coloane2/2-4,"New Game");
				attroff(COLOR_PAIR(CULOARE_TITLU));
				refresh();
			}

			if (colorat==1)
			{

				startx=linii/4+4;  
				starty=coloane/2-10;
				getmaxyx(NEW_GAME,linii2,coloane2);
				mvprintw(startx+linii2/2,starty+coloane2/2-4,"New Game");
				
				startx=3*(linii/4);   
				starty=coloane/2-10;
				getmaxyx(QUIT,linii2,coloane2);
				mvprintw(startx+linii2/2,starty+coloane2/2-2,"Quit");

				startx=2*(linii/4)+2; 
				starty=coloane/2-10;
				getmaxyx(RESUME_GAME,linii2,coloane2);
				attron(COLOR_PAIR(CULOARE_TITLU));
				mvprintw(startx+linii2/2,starty+coloane2/2-5,"Resume Game");
				attroff(COLOR_PAIR(CULOARE_TITLU));
				refresh();

			}

			if (colorat==2)
			{
				startx=linii/4+4;  
				starty=coloane/2-10;
				getmaxyx(NEW_GAME,linii2,coloane2);
				mvprintw(startx+linii2/2,starty+coloane2/2-4,"New Game");
				
				startx=2*(linii/4)+2; 
				starty=coloane/2-10;
				getmaxyx(RESUME_GAME,linii2,coloane2);
				mvprintw(startx+linii2/2,starty+coloane2/2-5,"Resume Game");

				startx=3*(linii/4);   
				starty=coloane/2-10;
				getmaxyx(QUIT,linii2,coloane2);
				attron(COLOR_PAIR(CULOARE_TITLU));
				mvprintw(startx+linii2/2,starty+coloane2/2-2,"Quit");
				attroff(COLOR_PAIR(CULOARE_TITLU));
				refresh();

			}
		int varianta;
		varianta=getch();
		data_si_ora(linii,coloane);
		switch(varianta)
		{
			case 259:
					{
						colorat--;
						if (colorat==-1)
							colorat=2;
						break;
					}
			case 258:
					{
						colorat++;
						if (colorat==3)
							colorat=0;
						break;
					}
			case 10:
					{
						if (colorat==0)
							aux=0;
						if (colorat==1)
							aux=1;
						if (colorat==2)
							aux=2;
						constanta=1;
						break;
					}
			default:break;

		}
	}
	return aux;
}

void optiunea50_50(struct ajutoare alfa,int linii,int coloane)
{
	if (alfa.boolean==1)
			mvprintw(linii/2+1,5*coloane/6,"50/50");

	if (alfa.boolean2==0)
		{
			attron(COLOR_PAIR(CULOARE_TITLU));
			mvprintw(linii/2+4,5*coloane/6-1,"(Skip the question)");
			attroff(COLOR_PAIR(CULOARE_TITLU));
		}
	
	if (alfa.boolean2==1)
		{
			mvprintw(linii/2+4,5*coloane/6-1,"Skip the question");
		}
	if (alfa.boolean==0)
	{
		attron(COLOR_PAIR(CULOARE_TITLU));
		mvprintw(linii/2+1,5*coloane/6,"(50/50)");
		attroff(COLOR_PAIR(CULOARE_TITLU));
	}
	mvprintw (linii-3,coloane-62,"Apasati 1 pentru a folosi 50/50 si 2 pentru Skip the question");
}