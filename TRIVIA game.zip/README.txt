Jocul Trivia

Pentru inceput, in joc apare meniul principal format din Start Game, Resume Game (inaccesibil) si Quit. 
Miscarea in meniu se face prin apasarea tastelor sageata sus si sageata jos. 
Odata accesat butonul Start Game prin apasarea tastei Enter, se incepe jocul. Se afiseaza intrebarile, miscarea prin raspunsuri se face tot cu tastele directionale, iar selectarea raspunsului se face cu tasta Enter.
Daca se doreste folosirea uneia dintre variantele ajutatoare 50/50 sau Skip the question, se apasa 1, respectiv 2. Acestea fiind folosite, devin inactive pentru urmatoarele intrebari. 
Daca se apasa tasta Q in oricare stadiu al jocului, se revine la meniul principal, iar meniul Resume Game devine activ, putand apoi fi folosit si revenind la intrebarea la care s-a utilizat tasta Q. 
La apasarea butonului Quit se inchide jocul. 

Pentru implementarea programului am folosit subprogramele: 

- creare_fereastra - primeste ca parametru inaltimea si latimea ferestrei si doua variabile startx si starty si creeaza ferestrele jocului;
-functia start_game - care este, de altfel, si cea mai complexa functie din program, primeste ca parametri cele trei ferestre (New Game, Resume Game si Quit), numarul de linii, numarul de coloane,
structura in care am preluat intrebarile din fisierul (fisierele) text, si o variabila a de care se foloseste pentru numarul de intrebari,struct ajutoare_alfa prin care se face legatura cu celelalte suprograme,
int numaratoare care tine evidenta numarului intrebarii,int scor care retine scorul;
-void creare_titlu care creeaza titlul fara a primi niciun parametru;
-preluare_intrebari este functia care primeste ca parametru struct intrebare si structura in care vor fi stocate intrebarile si preia intrebarile din fisierele text;
-functia afisare_intrebare_si_variante care primeste ca parametru numaratoare (adica numarul intrebarii), liniile si coloane terminalului, structura in care sunt stocate intrebarile si structura ajutoare_alfa prin intermediul careia se face legatura intre subprograme
-void data_si_ora este subprogramul folosit pentru afisarea datei si orei curente, iar acest subprogram este asezat langa fiecare getch() din program pentru a se actualiza data si ora la fiecare apasare a unei taste;
-int meniu si int meniu2 sunt functiile in care se afiseaza Resume Game inactiv, respectiv meniul in care Resume Game este activ;
-optiunea 50/50 este optiunea care afiseaza atat optiunea ajutatoare 50/50, cat si optiunea ajutatoare Skip the question 
si primeste ca parametru ajutoare_alfa, numarul de linii si numarul de coloane.
Jocul poate fi jucat in orice marime a terminalului, de la 105x30, pana la fullscreen.

Programul primeste ca parametrii in fisierul makefile intrebari.txt si intrebari2.txt , iar acesta poate primi oricate fisiere text cu intrebari ca parametrii , 
atata timp cat in fisiere se respecta urmatoarea structura a scrierii intrabarilor

Intrabare
raspuns a
raspuns b
raspuns c
raspuns d
raspuns corect

M-am straduit destul de mult ca aceasta tema sa iasa cat mai bine , sper sa va placa :D

